<?php
if(unlink('../post.log') == 1){
	echo "Deleted successfully";
}
else{
	echo "Failure, no log likely found.";
}
?>