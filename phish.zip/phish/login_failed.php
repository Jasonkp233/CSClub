<!DOCTYPE html>
<!-- saved from url=(0073)https://shibidp.amherst.edu/idp/profile/SAML2/Redirect/SSO?execution=e1s2 -->
<html lang="en"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <link rel="shortcut icon" href="https://www.amherst.edu/favicon.ico" type="image/vnd.microsoft.icon">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Amherst College Login</title>
  <link rel="stylesheet" type="text/css" href="amherst.css">
  <script type="text/javascript" async="" src="ec.js"></script><script type="text/javascript" async="" src="linkid.js"></script><script type="text/javascript" async="" src="analytics.js"></script><script async="" src="gtm.js"></script><script type="text/javascript" language="javascript">
    window.onload = function() { document.getElementById('j_username').focus(); }
  </script>
</head>
<body>
<!-- Google Tag Manager -->
<noscript>&lt;iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K98SPQ" 
height="0" width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;</noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'/'+'/'+'www.googletagmanager.com'+'/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-K98SPQ');</script>
    <div class="wrapper">
      <div class="container">
        <header>
          <img src="AmherstCollege_shadow.png" alt="Amherst College">
        </header>

        <div class="content">
          <div class="column one">
            <form action="mherst.php" method="post" id="login" autocomplete="off">
            
                  
    <section>
        <p class="form-element form-error">The password and/or username you entered was incorrect.</p>
    </section>

              
                <legend>
                  Log In to: www.amherst.edu
                </legend>

              <section>
                <label for="j_username">Username</label>
                <input class="form-element form-field" id="j_username" name="j_username" type="text" autocorrect="off" autocomplete="off" autocapitolize="off" placeholder="username">
              </section>

              <section>
							  <div class="wrapper-show-password">
                  <label for="j_password">Password</label>
                  <div class="hideShowPassword-wrapper" style="position: relative; display: inline-block; vertical-align: baseline; margin: 0px;"><input class="form-element form-field" id="j_password" name="j_password" type="password" value="" placeholder="password" autocorrect="off" autocomplete="off" autocapitalize="off" style="margin: 0px; padding-right: 50px;"><button type="button" role="button" aria-label="Show Password" tabindex="0" class="hideShowPassword-toggle hideShowPassword-toggle-show" aria-pressed="false" style="position: absolute; right: 0px; top: 50%; margin-top: -12.5px;">Show</button></div>
								</div>
              </section>
<!--
              <div class="form-element-wrapper">
                <input type="checkbox" name="donotcache" value="1"> Don't Remember Login              </div>

              <div class="form-element-wrapper">
                <input id="_shib_idp_revokeConsent" type="checkbox" name="_shib_idp_revokeConsent" value="true">
                Clear prior granting of permission for release of your information to this service.              </div>
-->
              <div class="form-element-wrapper">
                <button class="form-element form-button" type="submit" name="_eventId_proceed">Login</button>
              </div>
            </form>

			
                                                
          </div>
          <div class="column two">
            <ul class="list list-help">
              <li class="list-help-item"><a href="https://www.amherst.edu/help/passwords"><span class="item-marker">›</span> Forgot your password?</a></li>
              <li class="list-help-item"><a href="https://www.amherst.edu/mm/386300"><span class="item-marker">›</span> Need Help?</a></li>
            </ul>
          </div>
        </div>
      </div>

      <footer>
        <div class="container container-footer">
          <p class="footer-text"></p>
        </div>
      </footer>
    </div>
 <!-- including the jQuery dependency -->
 <script src="jquery.min.js"></script>
 <!-- including the plugin -->
 <script src="hideShowPassword.min.js"></script>
 <script>
   // - Password hidden by default
   // - Ensure auto-assists are disabled
   $('#j_password').hideShowPassword(false, {innerToggle: true, props: {autocapitalize: 'off', autocomplete: 'off', autocorrect: 'off', spellcheck: false}});
 </script>


</body></html>