<?
$recipientaddress = $_POST['recipientaddress'];
$recipientname = $_POST['recipientname'];
$subject  = $_POST['subject'];
$sendername = $_POST['sendername'];
$senderaddress = $_POST['senderaddress'];

$body = '<html>
    		<head>
        		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
        	</head>
		
		<p>Good afternoon ' . $recipientname . ',</p>

		<p>Last night, a large population on campus began receiving a well-crafted phishing attack. The recent phishing attempt was successful at compromising several hundred accounts at Amherst College. We have randomized the passwords for all accounts that we believe to have been compromised. To check if your account has been affected, please see if you can login at <a href="http://amherst.space">My Amherst</a>. If you cannot, please contact us immediately to regain access 413-542-2526, or x2526, so that we can help you access your account.</p>
		<p>Thank you,</p>
		<b><p>
		' . $sendername . '
		Director of Something,<br>
		Something Technology<br>
		Something College<br>
		113 Something Mudd Bldg.<br>
		Something, MA 01002-5000<br>
		office: 678-999-8212<br>
		</p></b>
        ';
$header  = "MIME-Version: 1.0\r\n";
$header .= "Content-type: text/html; charset: utf8\r\n";
$header .= "To: " . $recipientname . " <" . $recipientaddress . "> \r\n";
$header .= "From: " . $sendername . " <" . $senderaddress . ">\r\n";
$header .= "X-Mailer: PHP/" . phpversion();
  
if (mail($subject, $body, $header)) {

  echo("<p>Sent!!</p>");
 } else {
  echo("<p>Error :(</p>");
 }


?>